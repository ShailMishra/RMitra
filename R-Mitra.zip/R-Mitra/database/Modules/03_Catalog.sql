USE [RMitra];
GO

IF OBJECT_ID(N'cat.Cuisines', N'U') IS NULL
BEGIN
    CREATE TABLE cat.Cuisines
    (
        Code        NVARCHAR(50)  NOT NULL CONSTRAINT PK_Cuisines PRIMARY KEY,
        Name        NVARCHAR(100) NOT NULL,
        IsActive    BIT           NOT NULL CONSTRAINT DF_Cuisines_Active DEFAULT (1)
    );
END
GO

IF OBJECT_ID(N'cat.MenuCategories', N'U') IS NULL
BEGIN
    CREATE TABLE cat.MenuCategories
    (
        Id              UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_MenuCategories PRIMARY KEY,
        KitchenGuid     UNIQUEIDENTIFIER NOT NULL,
        Name            NVARCHAR(150)    NOT NULL,
        DisplayOrder    INT              NOT NULL CONSTRAINT DF_MenuCategories_Order DEFAULT (0),
        IsActive        BIT              NOT NULL CONSTRAINT DF_MenuCategories_Active DEFAULT (1),
        CreatedAt       DATETIME2        NOT NULL CONSTRAINT DF_MenuCategories_CreatedAt DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT FK_MenuCategories_Kitchen FOREIGN KEY (KitchenGuid) REFERENCES kit.Kitchens (Id)
    );
END
GO

IF OBJECT_ID(N'cat.MenuItems', N'U') IS NULL
BEGIN
    CREATE TABLE cat.MenuItems
    (
        Id                  UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_MenuItems PRIMARY KEY,
        ItemId              NVARCHAR(20)     NOT NULL,
        KitchenGuid         UNIQUEIDENTIFIER NOT NULL,
        CategoryId          UNIQUEIDENTIFIER NOT NULL,
        Name                NVARCHAR(200)    NOT NULL,
        Description         NVARCHAR(1000)   NULL,
        Price               DECIMAL(10,2)    NOT NULL,
        IsVeg               BIT              NOT NULL CONSTRAINT DF_MenuItems_IsVeg DEFAULT (1),
        Status              NVARCHAR(20)     NOT NULL CONSTRAINT DF_MenuItems_Status DEFAULT (N'DRAFT'),
        PhotoUrl            NVARCHAR(1000)   NULL,
        PreparationMinutes  INT              NOT NULL CONSTRAINT DF_MenuItems_Prep DEFAULT (20),
        CreatedAt           DATETIME2        NOT NULL CONSTRAINT DF_MenuItems_CreatedAt DEFAULT (SYSUTCDATETIME()),
        UpdatedAt           DATETIME2        NOT NULL CONSTRAINT DF_MenuItems_UpdatedAt DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_MenuItems_ItemId UNIQUE (ItemId),
        CONSTRAINT FK_MenuItems_Kitchen FOREIGN KEY (KitchenGuid) REFERENCES kit.Kitchens (Id),
        CONSTRAINT FK_MenuItems_Category FOREIGN KEY (CategoryId) REFERENCES cat.MenuCategories (Id)
    );
END
GO
