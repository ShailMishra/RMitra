USE [RMitra];
GO

IF OBJECT_ID(N'rev.Reviews', N'U') IS NULL
BEGIN
    CREATE TABLE rev.Reviews
    (
        Id              UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Reviews PRIMARY KEY,
        OrderGuid       UNIQUEIDENTIFIER NOT NULL,
        KitchenGuid     UNIQUEIDENTIFIER NOT NULL,
        CustomerUserId  UNIQUEIDENTIFIER NOT NULL,
        Rating          INT              NOT NULL,
        RiderRating     INT              NULL,
        Comments        NVARCHAR(1000)   NULL,
        CreatedAt       DATETIME2        NOT NULL CONSTRAINT DF_Reviews_CreatedAt DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_Reviews_OrderGuid UNIQUE (OrderGuid),
        CONSTRAINT CK_Reviews_Rating CHECK (Rating BETWEEN 1 AND 5),
        CONSTRAINT FK_Reviews_Order FOREIGN KEY (OrderGuid) REFERENCES ord.Orders (Id)
    );
END
GO

IF OBJECT_ID(N'sub.Plans', N'U') IS NULL
BEGIN
    CREATE TABLE sub.Plans
    (
        PlanCode        NVARCHAR(50)     NOT NULL CONSTRAINT PK_Plans PRIMARY KEY,
        Audience        NVARCHAR(20)     NOT NULL,
        Name            NVARCHAR(100)    NOT NULL,
        Price           DECIMAL(10,2)    NOT NULL,
        DurationDays    INT              NOT NULL
    );
END
GO

IF OBJECT_ID(N'sub.Subscriptions', N'U') IS NULL
BEGIN
    CREATE TABLE sub.Subscriptions
    (
        Id              UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Subscriptions PRIMARY KEY,
        SubscriptionId  NVARCHAR(20)     NOT NULL,
        UserId          UNIQUEIDENTIFIER NOT NULL,
        PlanCode        NVARCHAR(50)     NOT NULL,
        Audience        NVARCHAR(20)     NOT NULL,
        ValidUntil      DATETIME2        NOT NULL,
        AutoRenew       BIT              NOT NULL CONSTRAINT DF_Subscriptions_Renew DEFAULT (1),
        CreatedAt       DATETIME2        NOT NULL CONSTRAINT DF_Subscriptions_CreatedAt DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_Subscriptions_SubscriptionId UNIQUE (SubscriptionId),
        CONSTRAINT FK_Subscriptions_User FOREIGN KEY (UserId) REFERENCES idn.Users (Id),
        CONSTRAINT FK_Subscriptions_Plan FOREIGN KEY (PlanCode) REFERENCES sub.Plans (PlanCode)
    );
END
GO

IF OBJECT_ID(N'setl.LedgerLines', N'U') IS NULL
BEGIN
    CREATE TABLE setl.LedgerLines
    (
        Id          BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LedgerLines PRIMARY KEY,
        PartyType   NVARCHAR(20)         NOT NULL,
        PartyGuid   UNIQUEIDENTIFIER     NOT NULL,
        OrderGuid   UNIQUEIDENTIFIER     NOT NULL,
        Amount      DECIMAL(10,2)        NOT NULL,
        Description NVARCHAR(200)        NOT NULL,
        CreatedAt   DATETIME2            NOT NULL CONSTRAINT DF_Ledger_CreatedAt DEFAULT (SYSUTCDATETIME())
    );
END
GO

IF OBJECT_ID(N'setl.Settlements', N'U') IS NULL
BEGIN
    CREATE TABLE setl.Settlements
    (
        Id              UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_Settlements PRIMARY KEY,
        SettlementId    NVARCHAR(20)     NOT NULL,
        PartyType       NVARCHAR(20)     NOT NULL,
        PartyGuid       UNIQUEIDENTIFIER NOT NULL,
        PeriodStart     DATETIME2        NOT NULL,
        PeriodEnd       DATETIME2        NOT NULL,
        Amount          DECIMAL(10,2)    NOT NULL,
        Status          NVARCHAR(20)     NOT NULL,
        InvoiceUrl      NVARCHAR(500)    NULL,
        Utr             NVARCHAR(50)     NULL,
        CreatedAt       DATETIME2        NOT NULL CONSTRAINT DF_Settlements_CreatedAt DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_Settlements_SettlementId UNIQUE (SettlementId)
    );
END
GO
