/*
    HOMELY / RMitra dedicated database.
    Run against the SQL Server instance, not an existing application DB.
*/

IF DB_ID(N'RMitra') IS NULL
BEGIN
    CREATE DATABASE [RMitra];
END
GO

USE [RMitra];
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'core') EXEC('CREATE SCHEMA core');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'idn') EXEC('CREATE SCHEMA idn');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'kit') EXEC('CREATE SCHEMA kit');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'cat') EXEC('CREATE SCHEMA cat');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'cus') EXEC('CREATE SCHEMA cus');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'ord') EXEC('CREATE SCHEMA ord');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'pay') EXEC('CREATE SCHEMA pay');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'del') EXEC('CREATE SCHEMA del');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'rev') EXEC('CREATE SCHEMA rev');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'sub') EXEC('CREATE SCHEMA sub');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'setl') EXEC('CREATE SCHEMA setl');
GO

IF OBJECT_ID(N'core.NumberSeries', N'U') IS NULL
BEGIN
    CREATE TABLE core.NumberSeries
    (
        Prefix      NVARCHAR(10) NOT NULL CONSTRAINT PK_NumberSeries PRIMARY KEY,
        LastNumber  INT          NOT NULL
    );
END
GO
