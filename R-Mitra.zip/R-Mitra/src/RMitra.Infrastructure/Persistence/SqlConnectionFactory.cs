using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using RMitra.Application.Abstractions;

namespace RMitra.Infrastructure.Persistence;

public class SqlConnectionFactory : ISqlConnectionFactory
{
    private readonly string _connectionString;

    public SqlConnectionFactory(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("RMitra")
            ?? throw new InvalidOperationException("Connection string 'RMitra' is not configured.");
    }

    public IDbConnection Create() => new SqlConnection(_connectionString);
}
