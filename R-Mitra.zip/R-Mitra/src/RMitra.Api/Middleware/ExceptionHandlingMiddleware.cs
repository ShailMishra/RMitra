using System.Net;
using System.Text.Json;
using RMitra.BuildingBlocks.Exceptions;
using RMitra.BuildingBlocks.Responses;

namespace RMitra.Api.Middleware;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (AppException ex)
        {
            await Write(context, ex.StatusCode, ApiResponse.Fail(ex.ErrorCode, ex.Message, ex.Details));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception");
            await Write(context, (int)HttpStatusCode.InternalServerError,
                ApiResponse.Fail("ERROR", "An unexpected error occurred."));
        }
    }

    private static async Task Write(HttpContext context, int statusCode, ApiResponse payload)
    {
        context.Response.ContentType = "application/json";
        context.Response.StatusCode = statusCode;
        await context.Response.WriteAsync(JsonSerializer.Serialize(payload, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        }));
    }
}
