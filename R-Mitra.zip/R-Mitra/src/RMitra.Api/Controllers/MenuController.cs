using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Api.Uploads;
using RMitra.Application.Catalog;
using RMitra.BuildingBlocks.Responses;
using RMitra.BuildingBlocks.Security;

namespace RMitra.Api.Controllers;

[Authorize(Roles = Roles.KitchenOwner)]
[Route("v1/menu")]
[Tags("Catalog")]
public class MenuController : ApiControllerBase
{
    private readonly ICatalogService _catalog;
    private readonly ICurrentUser _currentUser;
    private readonly IWebHostEnvironment _env;

    public MenuController(ICatalogService catalog, ICurrentUser currentUser, IWebHostEnvironment env)
    {
        _catalog = catalog;
        _currentUser = currentUser;
        _env = env;
    }

    [HttpPost("items/{itemId}/photos")]
    public async Task<ActionResult<ApiResponse>> Photo(string itemId, IFormFile file, CancellationToken cancellationToken)
    {
        var url = await LocalFileStore.SaveAsync(_env, file, cancellationToken);
        await _catalog.AddPhotoAsync(itemId, _currentUser.UserId, url, cancellationToken);
        return Success(new { photoUrl = url });
    }

    [HttpPatch("items/{itemId}")]
    public async Task<ActionResult<ApiResponse>> Patch(string itemId, [FromBody] PatchMenuItemRequest request, CancellationToken cancellationToken) =>
        Success(await _catalog.PatchItemAsync(itemId, _currentUser.UserId, request, cancellationToken));

    [HttpDelete("items/{itemId}")]
    public async Task<ActionResult<ApiResponse>> Delete(string itemId, CancellationToken cancellationToken)
    {
        await _catalog.SoftDeleteItemAsync(itemId, _currentUser.UserId, cancellationToken);
        return Success(new { deleted = true });
    }
}
