using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Application.Identity;
using RMitra.BuildingBlocks.Responses;

namespace RMitra.Api.Controllers;

[AllowAnonymous]
[Route("v1/auth")]
[Tags("Authentication")]
public class AuthController : ApiControllerBase
{
    private readonly IIdentityService _identity;

    public AuthController(IIdentityService identity) => _identity = identity;

    [HttpPost("otp/send")]
    public async Task<ActionResult<SendOtpResponse>> SendOtp([FromBody] SendOtpRequest request, CancellationToken cancellationToken) =>
        Ok(await _identity.SendOtpAsync(request, cancellationToken));

    [HttpPost("otp/verify")]
    public async Task<ActionResult<VerifyOtpResponse>> VerifyOtp([FromBody] VerifyOtpRequest request, CancellationToken cancellationToken) =>
        Ok(await _identity.VerifyOtpAsync(request, cancellationToken));

    [HttpPost("password")]
    public async Task<ActionResult<ApiResponse>> SetPassword([FromBody] SetPasswordRequest request, CancellationToken cancellationToken)
    {
        await _identity.SetPasswordAsync(request, cancellationToken);
        return Success(new { message = "Password saved." });
    }

    [HttpPost("login")]
    public async Task<ActionResult<AuthSessionResponse>> Login([FromBody] LoginRequest request, CancellationToken cancellationToken) =>
        Ok(await _identity.LoginAsync(request, cancellationToken));
}
