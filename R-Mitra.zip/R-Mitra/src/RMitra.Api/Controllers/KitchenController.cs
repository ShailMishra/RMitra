using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Api.Uploads;
using RMitra.Application.Catalog;
using RMitra.Application.Kitchen;
using RMitra.Application.Ordering;
using RMitra.Application.Settlement;
using RMitra.BuildingBlocks.Responses;
using RMitra.BuildingBlocks.Security;

namespace RMitra.Api.Controllers;

[Route("v1/kitchens")]
[Tags("Kitchen")]
public class KitchenController : ApiControllerBase
{
    private readonly IKitchenService _kitchens;
    private readonly ICatalogService _catalog;
    private readonly IOrderingService _orders;
    private readonly ISettlementService _settlements;
    private readonly ICurrentUser _currentUser;
    private readonly IWebHostEnvironment _env;

    public KitchenController(
        IKitchenService kitchens,
        ICatalogService catalog,
        IOrderingService orders,
        ISettlementService settlements,
        ICurrentUser currentUser,
        IWebHostEnvironment env)
    {
        _kitchens = kitchens;
        _catalog = catalog;
        _orders = orders;
        _settlements = settlements;
        _currentUser = currentUser;
        _env = env;
    }

    [AllowAnonymous]
    [HttpPost]
    public async Task<ActionResult<ApiResponse>> Create([FromBody] CreateKitchenRequest request, CancellationToken cancellationToken) =>
        Success(await _kitchens.CreateAsync(_currentUser.IsAuthenticated ? _currentUser.UserId : Guid.Empty, request, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpPatch("{kitchenId}")]
    public async Task<ActionResult<ApiResponse>> Patch(string kitchenId, [FromBody] PatchKitchenRequest request, CancellationToken cancellationToken) =>
        Success(await _kitchens.PatchAsync(kitchenId, _currentUser.UserId, request, cancellationToken));

    [Authorize]
    [HttpGet("{kitchenId}")]
    public async Task<ActionResult<ApiResponse>> Get(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _kitchens.GetAsync(kitchenId, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpPost("{kitchenId}/documents")]
    public async Task<ActionResult<ApiResponse>> UploadDocument(string kitchenId, [FromForm] string documentType, IFormFile file, CancellationToken cancellationToken)
    {
        var url = await LocalFileStore.SaveAsync(_env, file, cancellationToken);
        return Success(await _kitchens.AddDocumentAsync(kitchenId, _currentUser.UserId, documentType, url, cancellationToken));
    }

    [Authorize]
    [HttpGet("{kitchenId}/documents")]
    public async Task<ActionResult<ApiResponse>> Documents(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _kitchens.GetDocumentsAsync(kitchenId, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpPost("{kitchenId}/submit")]
    public async Task<ActionResult<ApiResponse>> Submit(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _kitchens.SubmitAsync(kitchenId, _currentUser.UserId, IdempotencyKey, cancellationToken));

    [Authorize]
    [HttpGet("{kitchenId}/progress")]
    public async Task<ActionResult<ApiResponse>> Progress(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _kitchens.GetProgressAsync(kitchenId, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpPost("{kitchenId}/activate")]
    public async Task<ActionResult<ApiResponse>> Activate(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _kitchens.ActivateAsync(kitchenId, _currentUser.UserId, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpGet("{kitchenId}/dashboard")]
    public async Task<ActionResult<ApiResponse>> Dashboard(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _kitchens.GetDashboardAsync(kitchenId, _currentUser.UserId, cancellationToken));

    [AllowAnonymous]
    [HttpGet("nearby")]
    public async Task<ActionResult<ApiResponse>> Nearby([FromQuery] decimal latitude, [FromQuery] decimal longitude, [FromQuery] bool openNow = false, CancellationToken cancellationToken = default) =>
        Success(await _kitchens.NearbyAsync(latitude, longitude, openNow, cancellationToken));

    [AllowAnonymous]
    [HttpGet("{kitchenId}/storefront")]
    public async Task<ActionResult<ApiResponse>> Storefront(string kitchenId, [FromQuery] decimal? latitude, [FromQuery] decimal? longitude, CancellationToken cancellationToken) =>
        Success(await _catalog.GetStorefrontAsync(kitchenId, latitude, longitude, cancellationToken));

    [Authorize]
    [HttpGet("{kitchenId}/menu/categories")]
    public async Task<ActionResult<ApiResponse>> Categories(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _catalog.GetCategoriesAsync(kitchenId, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpPost("{kitchenId}/menu/categories")]
    public async Task<ActionResult<ApiResponse>> AddCategory(string kitchenId, [FromBody] CreateCategoryRequest request, CancellationToken cancellationToken) =>
        Success(await _catalog.AddCategoryAsync(kitchenId, _currentUser.UserId, request, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpPost("{kitchenId}/menu/items")]
    public async Task<ActionResult<ApiResponse>> AddItem(string kitchenId, [FromBody] CreateMenuItemRequest request, CancellationToken cancellationToken) =>
        Success(await _catalog.AddItemAsync(kitchenId, _currentUser.UserId, request, cancellationToken));

    [Authorize]
    [HttpGet("{kitchenId}/menu/items")]
    public async Task<ActionResult<ApiResponse>> Items(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _catalog.GetItemsAsync(kitchenId, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpGet("{kitchenId}/orders")]
    public async Task<ActionResult<ApiResponse>> Orders(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _orders.GetKitchenOrdersAsync(kitchenId, _currentUser.UserId, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpPost("{kitchenId}/orders/{orderId}/accept")]
    public async Task<ActionResult<ApiResponse>> Accept(string kitchenId, string orderId, CancellationToken cancellationToken) =>
        Success(await _orders.AcceptAsync(kitchenId, orderId, _currentUser.UserId, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpPost("{kitchenId}/orders/{orderId}/reject")]
    public async Task<ActionResult<ApiResponse>> Reject(string kitchenId, string orderId, CancellationToken cancellationToken) =>
        Success(await _orders.RejectAsync(kitchenId, orderId, _currentUser.UserId, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpPost("{kitchenId}/orders/{orderId}/status")]
    public async Task<ActionResult<ApiResponse>> Status(string kitchenId, string orderId, [FromQuery] string status, CancellationToken cancellationToken) =>
        Success(await _orders.UpdateKitchenStatusAsync(kitchenId, orderId, _currentUser.UserId, status, cancellationToken));

    [Authorize(Roles = Roles.KitchenOwner)]
    [HttpGet("{kitchenId}/ledger")]
    public async Task<ActionResult<ApiResponse>> Ledger(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _settlements.GetKitchenLedgerAsync(kitchenId, _currentUser.UserId, cancellationToken));
}
