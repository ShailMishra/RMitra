using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Application.Settlement;
using RMitra.Application.Subscription;
using RMitra.BuildingBlocks.Responses;
using RMitra.BuildingBlocks.Security;

namespace RMitra.Api.Controllers;

[Route("v1")]
[Tags("Subscriptions")]
public class SubscriptionController : ApiControllerBase
{
    private readonly ISubscriptionService _subscriptions;
    private readonly ICurrentUser _currentUser;

    public SubscriptionController(ISubscriptionService subscriptions, ICurrentUser currentUser)
    {
        _subscriptions = subscriptions;
        _currentUser = currentUser;
    }

    [AllowAnonymous]
    [HttpGet("subscriptions/plans")]
    public async Task<ActionResult<ApiResponse>> Plans([FromQuery] string? audience, CancellationToken cancellationToken) =>
        Success(await _subscriptions.GetPlansAsync(audience, cancellationToken));

    [Authorize]
    [HttpPost("subscriptions")]
    public async Task<ActionResult<ApiResponse>> Purchase([FromBody] PurchaseSubscriptionRequest request, CancellationToken cancellationToken) =>
        Success(await _subscriptions.PurchaseAsync(_currentUser.UserId, _currentUser.Role, request, cancellationToken));

    [Authorize]
    [HttpGet("subscriptions/me")]
    public async Task<ActionResult<ApiResponse>> Me(CancellationToken cancellationToken) =>
        Success(await _subscriptions.GetMineAsync(_currentUser.UserId, cancellationToken));

    [Authorize]
    [HttpPost("subscriptions/{id}/cancel")]
    public async Task<ActionResult<ApiResponse>> Cancel(string id, CancellationToken cancellationToken)
    {
        await _subscriptions.CancelAsync(id, _currentUser.UserId, cancellationToken);
        return Success(new { id, cancelled = true });
    }
}

[Route("v1")]
[Tags("Settlement")]
public class SettlementController : ApiControllerBase
{
    private readonly ISettlementService _settlements;

    public SettlementController(ISettlementService settlements) => _settlements = settlements;

    [Authorize]
    [HttpGet("settlements")]
    public async Task<ActionResult<ApiResponse>> List(CancellationToken cancellationToken) =>
        Success(await _settlements.ListAsync(cancellationToken));

    [Authorize]
    [HttpGet("settlements/{id}")]
    public async Task<ActionResult<ApiResponse>> Get(string id, CancellationToken cancellationToken) =>
        Success(await _settlements.GetAsync(id, cancellationToken));
}

[Route("v1/master")]
[Tags("Master")]
public class MasterController : ApiControllerBase
{
    private readonly RMitra.Application.Catalog.ICatalogService _catalog;

    public MasterController(RMitra.Application.Catalog.ICatalogService catalog) => _catalog = catalog;

    [AllowAnonymous]
    [HttpGet("cuisines")]
    public async Task<ActionResult<ApiResponse>> Cuisines(CancellationToken cancellationToken) =>
        Success(await _catalog.GetCuisinesAsync(cancellationToken));
}
