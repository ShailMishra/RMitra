using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Application.Customer;
using RMitra.BuildingBlocks.Responses;
using RMitra.BuildingBlocks.Security;

namespace RMitra.Api.Controllers;

[Route("v1/customers")]
[Tags("Customer")]
public class CustomerController : ApiControllerBase
{
    private readonly ICustomerService _customers;
    private readonly ICurrentUser _currentUser;

    public CustomerController(ICustomerService customers, ICurrentUser currentUser)
    {
        _customers = customers;
        _currentUser = currentUser;
    }

    [AllowAnonymous]
    [HttpPost]
    public async Task<ActionResult<RegisterCustomerResponse>> Register([FromBody] RegisterCustomerRequest request, CancellationToken cancellationToken) =>
        Ok(await _customers.RegisterAsync(request, cancellationToken));

    [Authorize(Roles = Roles.Customer)]
    [HttpGet("me")]
    public async Task<ActionResult<ApiResponse>> Me(CancellationToken cancellationToken) =>
        Success(await _customers.GetMeAsync(_currentUser.UserId, cancellationToken));

    [Authorize(Roles = Roles.Customer)]
    [HttpPatch("me")]
    public async Task<ActionResult<ApiResponse>> PatchMe([FromBody] PatchCustomerRequest request, CancellationToken cancellationToken) =>
        Success(await _customers.PatchMeAsync(_currentUser.UserId, request, cancellationToken));

    [Authorize(Roles = Roles.Customer)]
    [HttpGet("me/addresses")]
    public async Task<ActionResult<ApiResponse>> Addresses(CancellationToken cancellationToken) =>
        Success(await _customers.GetAddressesAsync(_currentUser.UserId, cancellationToken));

    [Authorize(Roles = Roles.Customer)]
    [HttpPost("me/addresses")]
    public async Task<ActionResult<ApiResponse>> AddAddress([FromBody] UpsertAddressRequest request, CancellationToken cancellationToken) =>
        Success(await _customers.AddAddressAsync(_currentUser.UserId, request, cancellationToken));
}
