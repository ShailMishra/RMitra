using Microsoft.AspNetCore.Mvc;
using RMitra.BuildingBlocks.Responses;

namespace RMitra.Api.Controllers;

[ApiController]
public abstract class ApiControllerBase : ControllerBase
{
    protected ActionResult<ApiResponse> Success(object? data = null) =>
        Ok(ApiResponse.Ok(data));

    protected string? IdempotencyKey => Request.Headers["Idempotency-Key"].FirstOrDefault();
}
