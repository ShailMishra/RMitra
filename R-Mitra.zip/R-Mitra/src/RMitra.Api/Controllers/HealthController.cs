using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Application.Abstractions;
using RMitra.BuildingBlocks.Responses;

namespace RMitra.Api.Controllers;

[AllowAnonymous]
[Route("v1/health")]
[Tags("Health")]
public class HealthController : ApiControllerBase
{
    private readonly ISqlConnectionFactory _connections;

    public HealthController(ISqlConnectionFactory connections) => _connections = connections;

    [HttpGet]
    public ActionResult<ApiResponse> Live() =>
        Success(new { status = "Healthy", product = "HOMELY", utc = DateTime.UtcNow });

    [HttpGet("ready")]
    public ActionResult<ApiResponse> Ready()
    {
        using var db = _connections.Create();
        db.Open();
        return Success(new { status = "Ready", utc = DateTime.UtcNow });
    }
}
