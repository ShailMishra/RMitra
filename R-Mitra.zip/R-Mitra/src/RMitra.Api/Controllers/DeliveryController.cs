using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Api.Uploads;
using RMitra.Application.Delivery;
using RMitra.Application.Settlement;
using RMitra.BuildingBlocks.Responses;
using RMitra.BuildingBlocks.Security;

namespace RMitra.Api.Controllers;

[Route("v1/riders")]
[Tags("Rider")]
public class RiderController : ApiControllerBase
{
    private readonly IRiderService _riders;
    private readonly ISettlementService _settlements;
    private readonly ICurrentUser _currentUser;
    private readonly IWebHostEnvironment _env;

    public RiderController(IRiderService riders, ISettlementService settlements, ICurrentUser currentUser, IWebHostEnvironment env)
    {
        _riders = riders;
        _settlements = settlements;
        _currentUser = currentUser;
        _env = env;
    }

    [AllowAnonymous]
    [HttpPost]
    public async Task<ActionResult<RegisterRiderResponse>> Register([FromBody] RegisterRiderRequest request, CancellationToken cancellationToken) =>
        Ok(await _riders.RegisterAsync(request, cancellationToken));

    [Authorize(Roles = Roles.Rider)]
    [HttpPost("me/documents")]
    public async Task<ActionResult<ApiResponse>> Documents([FromForm] string documentType, IFormFile file, CancellationToken cancellationToken)
    {
        var url = await LocalFileStore.SaveAsync(_env, file, cancellationToken);
        await _riders.AddDocumentAsync(_currentUser.UserId, documentType, url, cancellationToken);
        return Success(new { documentType, fileUrl = url });
    }

    [Authorize(Roles = Roles.Rider)]
    [HttpPost("me/submit")]
    public async Task<ActionResult<ApiResponse>> Submit(CancellationToken cancellationToken)
    {
        await _riders.SubmitAsync(_currentUser.UserId, cancellationToken);
        return Success(new { status = "SUBMITTED" });
    }

    [Authorize(Roles = Roles.Rider)]
    [HttpPut("me/presence")]
    public async Task<ActionResult<ApiResponse>> Presence([FromBody] PresenceRequest request, CancellationToken cancellationToken)
    {
        await _riders.SetPresenceAsync(_currentUser.UserId, request, cancellationToken);
        return Success(request);
    }

    [Authorize(Roles = Roles.Rider)]
    [HttpGet("me/assignments/current")]
    public async Task<ActionResult<ApiResponse>> Current(CancellationToken cancellationToken) =>
        Success(await _riders.GetCurrentAssignmentAsync(_currentUser.UserId, cancellationToken));

    [Authorize(Roles = Roles.Rider)]
    [HttpPost("me/assignments/{assignmentId}/respond")]
    public async Task<ActionResult<ApiResponse>> Respond(string assignmentId, [FromBody] RespondAssignmentRequest request, CancellationToken cancellationToken) =>
        Success(await _riders.RespondAsync(_currentUser.UserId, assignmentId, request, cancellationToken));

    [Authorize(Roles = Roles.Rider)]
    [HttpPost("me/trips/{orderId}/status")]
    public async Task<ActionResult<ApiResponse>> Trip(string orderId, [FromQuery] string status, CancellationToken cancellationToken)
    {
        await _riders.UpdateTripStatusAsync(_currentUser.UserId, orderId, status, cancellationToken);
        return Success(new { orderId, status });
    }

    [Authorize(Roles = Roles.Rider)]
    [HttpGet("me/ledger")]
    public async Task<ActionResult<ApiResponse>> Ledger(CancellationToken cancellationToken) =>
        Success(await _settlements.GetRiderLedgerAsync(_currentUser.UserId, cancellationToken));
}
