using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Application.Payment;
using RMitra.BuildingBlocks.Responses;

namespace RMitra.Api.Controllers;

[Route("v1")]
[Tags("Payment")]
public class PaymentController : ApiControllerBase
{
    private readonly IPaymentService _payments;

    public PaymentController(IPaymentService payments) => _payments = payments;

    [Authorize]
    [HttpPost("payments/{paymentId}/confirm")]
    public async Task<ActionResult<ApiResponse>> Confirm(string paymentId, [FromBody] ConfirmPaymentRequest request, CancellationToken cancellationToken) =>
        Success(await _payments.ConfirmAsync(paymentId, request, cancellationToken));

    [AllowAnonymous]
    [HttpPost("webhooks/payments")]
    public async Task<ActionResult<ApiResponse>> Webhook([FromBody] PaymentWebhookRequest request, CancellationToken cancellationToken) =>
        Success(await _payments.ProcessWebhookAsync(request, cancellationToken));
}
