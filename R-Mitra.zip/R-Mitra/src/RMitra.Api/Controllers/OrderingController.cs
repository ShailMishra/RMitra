using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Application.Ordering;
using RMitra.Application.Payment;
using RMitra.BuildingBlocks.Responses;
using RMitra.BuildingBlocks.Security;

namespace RMitra.Api.Controllers;

[Authorize]
[Route("v1")]
[Tags("Ordering")]
public class OrderingController : ApiControllerBase
{
    private readonly IOrderingService _orders;
    private readonly IPaymentService _payments;
    private readonly ICurrentUser _currentUser;

    public OrderingController(IOrderingService orders, IPaymentService payments, ICurrentUser currentUser)
    {
        _orders = orders;
        _payments = payments;
        _currentUser = currentUser;
    }

    [Authorize(Roles = Roles.Customer)]
    [HttpGet("cart")]
    public async Task<ActionResult<ApiResponse>> GetCart(CancellationToken cancellationToken) =>
        Success(await _orders.GetCartAsync(_currentUser.UserId, cancellationToken));

    [Authorize(Roles = Roles.Customer)]
    [HttpPut("cart")]
    public async Task<ActionResult<ApiResponse>> PutCart([FromBody] PutCartRequest request, CancellationToken cancellationToken) =>
        Success(await _orders.PutCartAsync(_currentUser.UserId, request, cancellationToken));

    [Authorize(Roles = Roles.Customer)]
    [HttpPost("orders")]
    public async Task<ActionResult<ApiResponse>> Place([FromBody] PlaceOrderRequest request, CancellationToken cancellationToken) =>
        Success(await _orders.PlaceOrderAsync(_currentUser.UserId, request, IdempotencyKey, cancellationToken));

    [HttpGet("orders")]
    public async Task<ActionResult<ApiResponse>> Mine(CancellationToken cancellationToken) =>
        Success(await _orders.GetMyOrdersAsync(_currentUser.UserId, _currentUser.Role, cancellationToken));

    [HttpGet("orders/{orderId}")]
    public async Task<ActionResult<ApiResponse>> Get(string orderId, CancellationToken cancellationToken) =>
        Success(await _orders.GetOrderAsync(orderId, _currentUser.UserId, _currentUser.Role, cancellationToken));

    [Authorize(Roles = Roles.Customer)]
    [HttpPost("orders/{orderId}/cancel")]
    public async Task<ActionResult<ApiResponse>> Cancel(string orderId, [FromBody] CancelOrderRequest request, CancellationToken cancellationToken) =>
        Success(await _orders.CancelAsync(orderId, _currentUser.UserId, request, cancellationToken));

    [Authorize(Roles = Roles.Customer)]
    [HttpPost("orders/{orderId}/payments")]
    public async Task<ActionResult<ApiResponse>> Pay(string orderId, CancellationToken cancellationToken) =>
        Success(await _payments.CreateForOrderAsync(orderId, _currentUser.UserId, cancellationToken));

    [Authorize(Roles = Roles.Customer)]
    [HttpPost("orders/{orderId}/rating")]
    public async Task<ActionResult<ApiResponse>> Rate(string orderId, [FromBody] RatingRequest request, CancellationToken cancellationToken)
    {
        await _orders.RateAsync(orderId, _currentUser.UserId, request, cancellationToken);
        return Success(new { orderId, request.Rating });
    }

    [HttpPut("orders/{orderId}/tracking")]
    [Authorize(Roles = Roles.Rider)]
    public async Task<ActionResult<ApiResponse>> Tracking(string orderId, [FromBody] RMitra.Application.Delivery.TrackingRequest request, [FromServices] RMitra.Application.Delivery.IRiderService riders, CancellationToken cancellationToken)
    {
        await riders.UpdateTrackingAsync(orderId, _currentUser.UserId, request, cancellationToken);
        return Success(new { orderId, request.Latitude, request.Longitude });
    }
}
