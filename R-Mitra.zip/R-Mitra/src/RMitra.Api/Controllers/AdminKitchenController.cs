using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RMitra.Application.Delivery;
using RMitra.Application.Kitchen;
using RMitra.Application.Settlement;
using RMitra.BuildingBlocks.Responses;
using RMitra.BuildingBlocks.Security;

namespace RMitra.Api.Controllers;

[Authorize(Roles = Roles.Admin)]
[Route("v1/admin")]
[Tags("Admin")]
public class AdminController : ApiControllerBase
{
    private readonly IKitchenService _kitchens;
    private readonly IRiderService _riders;
    private readonly ISettlementService _settlements;

    public AdminController(IKitchenService kitchens, IRiderService riders, ISettlementService settlements)
    {
        _kitchens = kitchens;
        _riders = riders;
        _settlements = settlements;
    }

    [HttpGet("kitchens/pending")]
    public async Task<ActionResult<ApiResponse>> Pending(CancellationToken cancellationToken) =>
        Success(await _kitchens.GetPendingAsync(cancellationToken));

    [HttpPost("kitchens/{kitchenId}/approve")]
    public async Task<ActionResult<ApiResponse>> Approve(string kitchenId, CancellationToken cancellationToken) =>
        Success(await _kitchens.ApproveAsync(kitchenId, cancellationToken));

    [HttpPost("kitchens/{kitchenId}/reject")]
    public async Task<ActionResult<ApiResponse>> Reject(string kitchenId, [FromBody] RejectKitchenRequest request, CancellationToken cancellationToken) =>
        Success(await _kitchens.RejectAsync(kitchenId, request, cancellationToken));

    [HttpPost("kitchens/{kitchenId}/request-documents")]
    public async Task<ActionResult<ApiResponse>> RequestDocuments(string kitchenId, [FromBody] RequestDocumentsRequest request, CancellationToken cancellationToken) =>
        Success(await _kitchens.RequestDocumentsAsync(kitchenId, request, cancellationToken));

    [HttpPost("riders/{riderId}/review")]
    public async Task<ActionResult<ApiResponse>> ReviewRider(string riderId, [FromBody] RiderReviewRequest request, CancellationToken cancellationToken)
    {
        await _riders.ReviewAsync(riderId, request, cancellationToken);
        return Success(new { riderId, request.Decision });
    }

    [HttpGet("settlement/config")]
    public ActionResult<ApiResponse> Config() => Success(_settlements.GetConfig());

    [HttpPost("settlements/run")]
    public async Task<ActionResult<ApiResponse>> Run(CancellationToken cancellationToken) =>
        Success(await _settlements.RunWeeklyAsync(cancellationToken));
}
