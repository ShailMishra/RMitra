using System.Reflection;
using Microsoft.OpenApi;

namespace RMitra.Api.Swagger;

public static class SwaggerConfiguration
{
    public static IServiceCollection AddHomelySwagger(this IServiceCollection services)
    {
        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen(options =>
        {
            options.SwaggerDoc("v1", new OpenApiInfo
            {
                Title = "HOMELY API",
                Version = "v1",
                Description = "HOMELY homemade food delivery — kitchen, customer, rider, payments, subscriptions, and settlement. Base path /v1."
            });

            options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Description = "Paste the JWT from POST /v1/auth/otp/verify or /v1/auth/login. Example: Bearer {token}",
                Name = "Authorization",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.Http,
                Scheme = "bearer",
                BearerFormat = "JWT"
            });

            options.AddSecurityRequirement(document => new OpenApiSecurityRequirement
            {
                [new OpenApiSecuritySchemeReference("Bearer", document)] = []
            });

            options.CustomSchemaIds(type => type.FullName?.Replace("+", ".") ?? type.Name);
            options.DescribeAllParametersInCamelCase();
            options.SupportNonNullableReferenceTypes();

            var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
            var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
            if (File.Exists(xmlPath))
            {
                options.IncludeXmlComments(xmlPath, includeControllerXmlComments: true);
            }
        });

        return services;
    }

    public static WebApplication UseHomelySwagger(this WebApplication app)
    {
        app.UseSwagger(options =>
        {
            options.RouteTemplate = "swagger/{documentName}/swagger.json";
        });

        app.UseSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "HOMELY API v1");
            options.RoutePrefix = "swagger";
            options.DocumentTitle = "HOMELY API — Swagger";
            options.DisplayRequestDuration();
            options.EnableDeepLinking();
            options.EnableFilter();
            options.EnableTryItOutByDefault();
            options.EnablePersistAuthorization();
            options.DefaultModelsExpandDepth(-1);
        });

        app.MapGet("/", () => Results.Redirect("/swagger", permanent: false))
            .ExcludeFromDescription()
            .AllowAnonymous();

        return app;
    }
}
