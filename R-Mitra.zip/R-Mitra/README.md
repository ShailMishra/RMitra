# HOMELY (RMitra)

Homemade food delivery platform. Solution name is **RMitra**; product brand and API contracts follow **HOMELY API Requirements Specification v4.1**.

Base path: `/v1`  
JSON: camelCase  
Roles: `CUSTOMER`, `KITCHEN_OWNER`, `RIDER`, `ADMIN`

## Architecture

Clean Architecture + modular monolith. Each module has its own API surface and SQL schema so it can be extracted later.

| Module | Schema | Spec coverage |
|---|---|---|
| Auth | `idn` | OTP, password, role-scoped JWT |
| Kitchen | `kit` | 4-step homemade registration, KYC, activate |
| Catalog | `cat` | Cuisines, categories, publish dishes |
| Customer | `cus` | Profile and GPS addresses |
| Ordering | `ord` | Nearby, cart, checkout, kitchen inbox |
| Payment | `pay` | UPI/card/netbanking/wallet/COD + webhook |
| Rider | `del` | KYC, offers, tracking, kitchen self-delivery |
| Review | `rev` | Kitchen + rider rating after DELIVERED |
| Subscription | `sub` | HomelyPlus and Featured Kitchen |
| Settlement | `setl` | Ledgers and weekly payout |

Locked rules from the spec: HOMEMADE only, one kitchen per mobile, FSSAI optional, 15% commission + 18% GST, rider 80% of delivery fee, HomelyPlus ₹149/₹399/₹999, Featured ₹499/month.

## Create the dedicated database

Run in order on SQL Server (not on another app database):

1. `database/00_CreateDatabase.sql`
2. `database/Modules/01_Identity.sql` through `08_Review.sql`
3. `database/Modules/99_SeedData.sql`

Or:

```bash
sqlcmd -S localhost -E -i database\Install_All.sql
```

## Run the API

Set `ConnectionStrings:RMitra` in `src/RMitra.Api/appsettings.json`.

Requires the .NET 10 SDK.

```bash
dotnet run --project src/RMitra.Api
```

Swagger UI: `http://localhost:5116/swagger` (the app root `/` redirects here). Use **Authorize** and paste the JWT from login or OTP verify.

Admin login (after DB seed):

`POST /v1/auth/login` with `mobileNumber=9999999999`, `password=Admin@123`, `purpose=ADMIN`.

In Development, OTP send returns `debugOtp`.

## Kitchen path

1. `POST /v1/auth/otp/send` purpose `KITCHEN_OWNER`
2. `POST /v1/auth/otp/verify`
3. `POST /v1/auth/password`
4. `POST /v1/kitchens` → `PATCH` address/cuisine/bank → upload `KITCHEN_PHOTO` + `PAN_CARD` → `POST .../submit`
5. Admin `POST /v1/admin/kitchens/{kitchenId}/approve`
6. Create and publish menu, then `POST .../activate`

## Customer path

1. OTP purpose `CUSTOMER` → `POST /v1/customers`
2. `POST /v1/customers/me/addresses` (lat/lng required)
3. `GET /v1/kitchens/nearby`
4. `PUT /v1/cart` → `POST /v1/orders` with `Idempotency-Key`
5. Online: `POST /v1/orders/{id}/payments` then confirm or webhook
6. After `DELIVERED`, `POST /v1/orders/{id}/rating`
